/*
 * Copyright (c) 2001, 2002, 2003, eVelopers Corp. All rights reserved.
 *
 * This software is distributed under the terms of the GNU General
 * Public License as published by the Free Software Foundation.
 */
package com.evelopers.unimod.samples.prison;

import com.evelopers.unimod.runtime.context.Parameter;
import com.evelopers.unimod.runtime.StateMachineConfig;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.evelopers.unimod.runtime.context.StateMachineContextImpl;

/**
 * com.evelopers.unimod.samples.prison.Prison
 *
 * @author Maxim Mazin
 * @version Revision: 1
 */
public class Prison {
    public static final int PRISONERS_NUMBER = 10;

    private static final String PRISONERS_PARAMETER = "PRISONERS";
    private static final String CURRENT_PRISONER_PARAMETER = "CURRENT_PRISONER";
    private static final String CURRENT_DAY_PARAMETER = "CURRENT_DAY";
    private static final String PUNISHED_PRISONERS_PARAMETER = "PUNISHED_PRISONERS";
    private static final String NOTIFIED_PARAMETER = "NOTIFIED";

    private static StateMachineContext.Context applicationContext = new StateMachineContextImpl.ContextImpl();

    public static StateMachineContext.Context getApplicationContext() {
        return applicationContext;
    }

    /**
     * Fetches current prisoner index from <b>event</b> context.
     * @return  current prisoner index
     */
    public static int getCurrentPrisoner(StateMachineContext context) {
    	synchronized (context) {
    		if (context.getEventContext() == null) {
    			return -1;
    		}

            return ((Integer) context.getEventContext().getParameter(CURRENT_PRISONER_PARAMETER)).intValue();
        }
    }

    /**
     * Puts current prisoner index to <b>event</b> context.
     */
    public static Parameter createCurrentPrisonerParameter(int currentPrisoner) {
    	return new Parameter(CURRENT_PRISONER_PARAMETER, new Integer(currentPrisoner));
    }

    /**
     * Fetches current day from <b>event</b> context.
     * @return current day
     */
    public static int getCurrentDay(StateMachineContext context) {
    	synchronized (context) {
    		if (context.getEventContext() == null) {
    			return -1;
    		}

            return ((Integer) context.getEventContext().getParameter(CURRENT_DAY_PARAMETER)).intValue();
        }
    }

    /**
     * Puts current day to <b>event</b> context.
     */
    public static Parameter createCurrentDayParameter(int currentDay) {
    	return new Parameter(CURRENT_DAY_PARAMETER, new Integer(currentDay));
    }

    /**
     * Fetches prisoners' configs from <b>application</b> context.
     * @return  prisoners' configs
     */
    public static StateMachineConfig[] getPrisoners(StateMachineContext context) {
        synchronized (context) {
            return ((StateMachineConfig[]) context.getApplicationContext().getParameter(
                    PRISONERS_PARAMETER));
        }
    }

    /**
     * Creates prisoners' configs in <b>application</b> context.
     */
    public static void createPrisoners(StateMachineContext context) {
        synchronized (context) {
            context.getApplicationContext().setParameter(
                    PRISONERS_PARAMETER, new StateMachineConfig[PRISONERS_NUMBER]);
        }
    }

    /**
     * Using <b>application</b> context checks whether every prisoner
     * was in punishment cell.
     * @return  whether every prisoner
     * was in punishment cell
     */
    public static boolean hasEverybodyVisited(StateMachineContext context) {
        synchronized (context) {
            boolean[] punishedPrisoners = (boolean[]) context.getApplicationContext().getParameter(
                    PUNISHED_PRISONERS_PARAMETER);
            if (punishedPrisoners != null) {
                for (int i = 0; i < punishedPrisoners.length; i++) {
                    if (!punishedPrisoners[i]) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
    }

    /**
     * Notes in <b>application</b> context that given prisoner has visited
     * punishment cell.
     */
    public static void visitedBy(StateMachineContext context, int currentPrisoner) {
        synchronized (context) {
            boolean[] punishedPrisoners = (boolean[]) context.getApplicationContext().getParameter(
                    PUNISHED_PRISONERS_PARAMETER);
            if (punishedPrisoners == null) {
                punishedPrisoners = new boolean[PRISONERS_NUMBER];
                context.getApplicationContext().setParameter(
                        PUNISHED_PRISONERS_PARAMETER, punishedPrisoners);
            }
            punishedPrisoners[currentPrisoner] = true;
        }
    }

    /**
     * Using <b>application</b> context checks whether jailer is notified.
     * @return whether jailer is notified
     */
    public static boolean isNotified(StateMachineContext context) {
        synchronized (context) {
            Boolean notified = ((Boolean) context.getApplicationContext().getParameter(
                    NOTIFIED_PARAMETER));
            return notified != null && notified.booleanValue();
        }
    }

    /**
     * Notes in <b>application</b> context that jailer is notified.
     */
    public static void setNotified(StateMachineContext context, boolean notified) {
        synchronized (context) {
            context.getApplicationContext().setParameter(NOTIFIED_PARAMETER, new Boolean(notified));
        }
    }
}