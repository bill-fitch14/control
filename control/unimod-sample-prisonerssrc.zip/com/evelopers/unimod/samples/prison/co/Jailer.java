/*
 * Copyright (c) 2001, 2002, 2003, eVelopers Corp. All rights reserved.
 *
 * This software is distributed under the terms of the GNU General
 * Public License as published by the Free Software Foundation.
 */

package com.evelopers.unimod.samples.prison.co;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.evelopers.unimod.samples.prison.Prison;

/**
 * com.evelopers.unimod.samples.prison.co.Jailer
 *
 * @author Maxim Mazin
 * @version Revision: 1
 */
public class Jailer implements ControlledObject {
    private static final Log log = LogFactory.getLog(Jailer.class);
    
    /**
     * Notify jailer that every prisoner has visited the punishment cell.
     * @unimod.action.descr Notify jailer that every prisoner has visited the punishment cell
     */
    public void z1(StateMachineContext context) {
        Prison.setNotified(context, true);
        log.info(">> Notify jailer");
    }
}