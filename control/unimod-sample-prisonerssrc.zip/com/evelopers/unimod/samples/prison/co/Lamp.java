package com.evelopers.unimod.samples.prison.co;

/*
 * Copyright (c) 2001, 2002, 2003, eVelopers Corp. All rights reserved.
 *
 * This software is distributed under the terms of the GNU General
 * Public License as published by the Free Software Foundation.
 */

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * com.evelopers.unimod.samples.prison.co.Lamp
 *
 * @author Maxim Mazin
 * @version Revision: 1
 */
public class Lamp implements ControlledObject {
    private static final Log log = LogFactory.getLog(Lamp.class);
    private boolean turnedOn = Math.random() > 0.5;

    /**
     * The lamp is turned on
     * @return whether the lamp is turned on.
     * @unimod.action.descr The lamp is turned on
     */
    public boolean x1(StateMachineContext context) {
        log.info(">>Lamp is " + (turnedOn ? "on" : "off"));
        return turnedOn;
    }

    /**
     * Turn off the lamp.
     * @unimod.action.descr Turn off the lamp
     */
    public void z1(StateMachineContext context) {
        log.info(">>Turn lamp off");
        turnedOn = false;
    }

    /**
     * Turn on the lamp
     * @unimod.action.descr Turn on the lamp
     */
    public void z2(StateMachineContext context) {
        log.info(">>Turn lamp on");
        turnedOn = true;
    }
}