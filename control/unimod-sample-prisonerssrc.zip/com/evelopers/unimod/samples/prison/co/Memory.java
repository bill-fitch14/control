package com.evelopers.unimod.samples.prison.co;

/*
 * Copyright (c) 2001, 2002, 2003, eVelopers Corp. All rights reserved.
 *
 * This software is distributed under the terms of the GNU General
 * Public License as published by the Free Software Foundation.
 */

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.evelopers.unimod.samples.prison.Prison;

/**
 * com.evelopers.unimod.samples.prison.co.Memory
 *
 * @author Maxim Mazin
 * @version Revision: 1
 */
public class Memory implements ControlledObject {
    private static final Log log = LogFactory.getLog(Memory.class);
    private int counter;

    /**
     * The number of the day
     * @return number of the day.
     * @unimod.action.descr The number of the day
     */
    public int x1(StateMachineContext context) {
        int currentDay = Prison.getCurrentDay(context);
        log.info(">>Current day is " + currentDay);
        return currentDay;
    }

    /**
     * Current counter value.
     * @return counter value.
     * @unimod.action.descr Current counter value
     */
    public int x2(StateMachineContext context) {
        log.info(">>Counter value is " + counter);
        return counter;
    }

    /**
     * Initialize counter with unit.
     * @unimod.action.descr Initialize counter with unit
     */
    public void z1(StateMachineContext context) {
        counter = 1;
        log.info(">>Initialize counter with 1");
    }

    /**
     * Increase the number of the day by unit.
     * @unimod.action.descr Increase the number of the day by unit
     */
    public void z2(StateMachineContext context) {
        counter ++;
        log.info(">>Increment counter");
    }
}