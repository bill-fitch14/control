/*
 * Copyright (c) 1999-2004 eVelopers Corporation. All rights reserved.
 *
 * This is open source software; you can use, redistribute and/or modify 
 * it under the terms of the Open Software Licence v 2.1 as published by the Open 
 * Source Initiative.
 *
 * You should have received a copy of the Open Software Licence along with this
 * application; if not, contact the Open Source Initiative (http://opensource.org).
 */
package com.evelopers.unimod.samples.prison.ep;

import com.evelopers.unimod.core.stateworks.Event;
import com.evelopers.unimod.runtime.EventProvider;
import com.evelopers.unimod.runtime.ModelEngine;
import com.evelopers.unimod.runtime.context.Parameter;
import com.evelopers.unimod.runtime.context.StateMachineContext;
import com.evelopers.unimod.runtime.context.StateMachineContextImpl;
import com.evelopers.unimod.samples.prison.Prison;

/**
 * @author Maxim Mazin
 * @version Revision: 1
 */
public class Warden implements EventProvider {
    /**
     * @unimod.event.descr Prisoner selected and put to the cell
     */
    public static final String E1 = "e1";

    /**
     * @unimod.event.descr Prisoner freed
     */
    public static final String E2 = "e2";

    /**
     * @unimod.event.descr Prisoner executed
     */
    public static final String E3 = "e3";

    private ModelEngine engine = null;
    private int currentDay = 1;
    boolean dispose = false;
    private Thread thread;

    public void init(ModelEngine engine) {
        this.engine = engine;

        thread = new Thread() {
                    public void run() {
                        while (! thread.isInterrupted()) {
                            try {
                                Thread.sleep(10);
                            } catch (InterruptedException e) {
                                return;
                            }
                            tick();
                        }
                    }
                };
        thread.start();
    }

    public void dispose() {
        if (thread != null) {
            thread.interrupt();
        }
    }

    /**
     * Sends next event
     */
    private void tick() {
        StateMachineContext context = createContext();

        if (!Prison.isNotified(context)) {
            e1();
        } else {
            if (Prison.hasEverybodyVisited(context)) {
                e2();
            } else {
                e3();
            }
        }
    }

    /**
     * Selects prisoner and moves it to punishment cell.
     */
    public void e1() {
        int currentPrisoner = (int) (Math.random() * Prison.PRISONERS_NUMBER);

        StateMachineContext context = createContext();

        Event e1 = new Event(
                E1, new Parameter[]{
                    Prison.createCurrentPrisonerParameter(currentPrisoner),
                    Prison.createCurrentDayParameter(currentDay++)
                });
        engine.getEventManager().handle(e1, context);
        Prison.visitedBy(context, currentPrisoner);
    }

    /**
     * Frees every prisoner.
     */
    public void e2() {
        for (int currentPrisoner = 0; currentPrisoner < Prison.PRISONERS_NUMBER; currentPrisoner++) {
            Event e2 = new Event(
                    E2, new Parameter[]{
                        Prison.createCurrentPrisonerParameter(currentPrisoner),
                        Prison.createCurrentDayParameter(currentDay),
                    });
            engine.getEventManager().handle(e2, createContext());
        }
    }

    /**
     * Executes every prisoner.
     */
    public void e3() {
        for (int currentPrisoner = 0; currentPrisoner < Prison.PRISONERS_NUMBER; currentPrisoner++) {
            Event e3 = new Event(
                    E3, new Parameter[]{
                        Prison.createCurrentPrisonerParameter(currentPrisoner),
                        Prison.createCurrentDayParameter(currentDay),
                    });
            engine.getEventManager().handle(e3, createContext());
        }
    }

    private StateMachineContext createContext() {
        return new StateMachineContextImpl(
                Prison.getApplicationContext(), null, new StateMachineContextImpl.ContextImpl());
    }
}