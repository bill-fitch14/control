package com.evelopers.unimod.samples.prison;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.evelopers.unimod.runtime.StateMachineConfig;
import com.evelopers.unimod.runtime.StateMachineConfigManager;
import com.evelopers.unimod.runtime.StateMachinePath;
import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * <p>
 * Configs for prisoners and index of current prisoner are stored in
 * the application context. On {@link #load} this config store returns
 * config of current prisoner.
 * </p>
 * <p>
 * On {@link #store} this config store checks if configs for prisoners are
 * initialized. If they are not then it copies given config to every
 * prisoner. If they are then current prisoner's config is assigned to
 * value of given config. It means that initialization event (that is
 * sent by {@link com.evelopers.unimod.runtime.ModelEngine engine} on
 * startup) is broadcasted to every prisoner, other events are sent directly
 * to current prisoner.
 * </p>
 */
public class CurrentPrisonerConfigStore implements StateMachineConfigManager {
    private static final Log log = LogFactory
            .getLog(CurrentPrisonerConfigStore.class);
    
    public void init(
            StateMachinePath path, StateMachineContext context, StateMachineConfig initialConfig) {
        if (Prison.getPrisoners(context) == null) {
            Prison.createPrisoners(context);
        }

        store(path, context, initialConfig);
    }

    public StateMachineConfig load(StateMachinePath path, StateMachineContext context) {
        /* Log current day and current prisoner */
        if (context.getApplicationContext() != null && context.getEventContext() != null) {
            int currentDay = Prison.getCurrentDay(context);
            int currentPrisoner = Prison.getCurrentPrisoner(context);
            String day = currentDay != -1 ? String.valueOf(currentDay) : "undefined";
            String prisoner = currentPrisoner != -1 ? String.valueOf(currentPrisoner) : "undefined";
            log.debug("Day: " + day + ", Prisoner: " + prisoner);
        }

        /* Check weather prisoners were initialized */
        if (Prison.getPrisoners(context) != null) {
            int currentPrisoner = Prison.getCurrentPrisoner(context);
            return Prison.getPrisoners(context)[currentPrisoner];
        } else {
            return null;
        }
    }

    public void store(StateMachinePath path, StateMachineContext context, StateMachineConfig config){
        StateMachineConfig[] prisoners = Prison.getPrisoners(context);
        int currentPrisoner = Prison.getCurrentPrisoner(context);
        if (currentPrisoner >= 0 && currentPrisoner < prisoners.length) {
            prisoners[currentPrisoner] = config;
        } 
    }

    public void dispose(
            StateMachinePath path, StateMachineContext context, StateMachineConfig finalConfig) {
    }
}
